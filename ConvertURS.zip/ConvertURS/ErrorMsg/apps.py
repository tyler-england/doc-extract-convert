from django.apps import AppConfig


class ErrorMsgConfig(AppConfig):
    name = 'ErrorMsg'
