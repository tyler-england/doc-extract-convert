from django.apps import AppConfig


class UploadDownloadConfig(AppConfig):
    name = 'UploadDownload'
